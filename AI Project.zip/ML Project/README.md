# Project README

## Overview
This project is a Jupyter Notebook (`project.ipynb`) focused on performing data loading, exploration, and basic analysis on a diabetes dataset (`DiabetesDataSet.csv`).

## Contents

### 1. Importing Libraries
The notebook begins by importing essential data science libraries:
- **pandas**
- **numpy**

### 2. Data Loading
The dataset is loaded using:
```python
df = pd.read_csv("DiabetesDataSet.csv")
```

### 3. Data Exploration
The notebook includes the following exploratory steps:
- Displaying the first rows using `df.head()`
- Summary statistics using `df.describe()`
- Dataset info using `df.info()`
- Checking data shape with `df.shape`
- Counting non-null values with `df.count()`

## How to Run
1. Ensure you have Python installed (3.8+ recommended).
2. Install required libraries:
   ```bash
   pip install pandas numpy jupyter
   ```
3. Open the notebook:
   ```bash
   jupyter notebook project.ipynb
   ```

## Dataset
The notebook expects a file named **DiabetesDataSet.csv** in the same directory.

## Purpose
The notebook provides a simple workflow for:
- Loading a medical dataset
- Performing initial exploratory data analysis (EDA)
- Understanding dataset structure

## Files
- `project.ipynb` – Main Jupyter Notebook
- `DiabetesDataSet.csv` – Input dataset (not included here)
- `README.md` – Documentation file (this file)

